
-- BLOOD BANK MANAGEMENT ANALYSIS

CREATE DATABASE bloodgroup_Analysis;
USE bloodgroup_Analysis;
--------------------------------------------------------
-- 1. Table: Donars
--------------------------------------------------------
CREATE TABLE Donars (
    DonarID INT PRIMARY KEY,
    Name VARCHAR(50),
    Bloodtype CHAR(3) NOT NULL,
    Contactnumber BIGINT UNIQUE,
    Address VARCHAR(100),
    LastDonationDate DATE
);


INSERT INTO Donars (DonarID, Name, Bloodtype, Contactnumber, Address, LastDonationDate) VALUES
(1,'satya','B+','903012','vizag','2025-01-01'),
(2,'naidu','O+','983451','chennai','2025-08-22'),
(3,'indu','AB+','911211','vizianagaram','2023-07-10'),
(4,'vanu','O-','802341','hyderabad','2024-08-11'),
(5,'hasini','A-','893504','mumbai','2023-08-15'),
(6,'sai','AB-','903015','vizag','2025-09-13'),
(7,'roshi','B+','754075','mumbai','2022-05-19'),
(8,'abbu','O+','631431','Delhi','2020-12-22'),
(9,'sahithi','B-','712334','mumbai','2022-08-12'),
(10,'Aarav','A+','900001','Delhi','2025-01-15'),
(11,'Ishaan','O+','900002','Hyderabad','2024-12-20'),
(12,'Meera','B+','900003','Vizag','2023-07-05'),
(13,'Rohan','AB+','900004','Mumbai','2022-09-11'),
(14,'Divya','O-','900005','Chennai','2025-02-02'),
(15,'Kiran','A-','900006','Jaipur','2025-03-15'),
(16,'Sanya','AB-','900007','Kolkata','2025-04-10'),
(17,'Aditya','B-','900008','Delhi','2024-11-25'),
(18,'Nikhil','A+','900009','Vizianagaram','2023-06-30'),
(19,'Priya','O+','900010','Bangalore','2022-05-15'),
(109,'Simran','O+','900109','Chennai','2025-08-29'),
(110,'Ritika','A+','900110','Hyderabad','2025-01-12'),
(111,'Vikram','O-','900111','Delhi','2024-11-18'),
(112,'Anjali','B+','900112','Mumbai','2023-09-25'),
(113,'Arnav','AB+','900113','Chennai','2025-06-05'),
(114,'Tanya','A-','900114','Bangalore','2022-08-20'),
(115,'Yash','O+','900115','Jaipur','2024-12-09'),
(116,'Pooja','B-','900116','Kolkata','2025-02-01'),
(117,'Krishna','AB-','900117','Delhi','2023-11-15'),
(118,'Sneha','A+','900118','Pune','2025-03-03'),
(119,'Deepak','O+','900119','Hyderabad','2022-07-07'),
(120,'Manish','B+','900120','Lucknow','2025-04-10'),
(121,'Shreya','AB+','900121','Ahmedabad','2023-05-22'),
(122,'Rahul','A-','900122','Delhi','2025-01-29'),
(123,'Nisha','O-','900123','Chennai','2024-03-18'),
(124,'Amit','B+','900124','Vizag','2025-06-11'),
(125,'Kavya','O+','900125','Hyderabad','2023-07-13'),
(126,'Harsh','A+','900126','Mumbai','2024-09-20'),
(127,'Ira','AB-','900127','Delhi','2025-05-05'),
(128,'Varun','B-','900128','Chennai','2022-11-23'),
(129,'Diya','O+','900129','Bangalore','2023-01-15'),
(130,'Mohit','A+','900130','Pune','2024-10-01'),
(131,'Rhea','AB+','900131','Hyderabad','2025-08-09'),
(132,'Arjun','O-','900132','Delhi','2023-09-17'),
(133,'Neha','B+','900133','Jaipur','2025-02-14'),
(134,'Kabir','A-','900134','Mumbai','2022-12-19'),
(135,'Sanya','O+','900135','Bangalore','2025-04-03'),
(136,'Dev','B+','900136','Lucknow','2023-06-06'),
(137,'Mira','AB-','900137','Delhi','2025-05-25'),
(138,'Siddharth','A+','900138','Pune','2024-08-08'),
(139,'Anaya','O+','900139','Hyderabad','2023-02-11'),
(140,'Kunal','B+','900140','Chennai','2025-07-02'),
(141,'Radhika','AB+','900141','Delhi','2023-03-09'),
(142,'Nitin','O-','900142','Bangalore','2024-11-30'),
(143,'Ishita','A+','900143','Vizag','2025-01-21'),
(144,'Parth','O+','900144','Mumbai','2022-06-16'),
(145,'Tanvi','B-','900145','Jaipur','2025-08-05'),
(146,'Jay','A-','900146','Hyderabad','2023-04-28'),
(147,'Aisha','AB-','900147','Delhi','2024-10-19'),
(148,'Om','B+','900148','Lucknow','2025-03-27'),
(149,'Sara','O+','900149','Chennai','2023-05-12'),
(150,'Reyansh','A+','900150','Bangalore','2025-06-08'),
(151,'Mahi','AB+','900151','Pune','2023-07-19'),
(152,'Dhruv','O-','900152','Hyderabad','2024-09-02'),
(153,'Avni','B+','900153','Delhi','2025-08-24'),
(154,'Rohan','A-','900154','Mumbai','2023-11-11'),
(155,'Lavanya','O+','900155','Jaipur','2025-02-16'),
(156,'Atharv','B+','900156','Vizag','2024-01-30'),
(157,'Suhani','AB-','900157','Chennai','2025-05-17'),
(158,'Arush','A+','900158','Hyderabad','2023-10-22'),
(159,'Muskan','O+','900159','Delhi','2025-09-01');

select *from Donars;
--------------------------------------------------------
-- 2. Table: BloodBanks
--------------------------------------------------------
CREATE TABLE BloodBanks (
    BloodBankID INT PRIMARY KEY,
    Name VARCHAR(100),
    Location VARCHAR(100),
    ContactNumber BIGINT
);

INSERT INTO BloodBanks (BloodBankID, Name, Location, ContactNumber) VALUES
(101,'CityBloodBank','Delhi',01123),
(102,'Coastal Blood','Mumbai',02234),
(103,'Palamoor Blood Bank','Vizag',91830),
(104,'Agarsen Blood Bank','Jaipur',91149),
(105,'Freedom Blood Bank','Rajasthan',91173),
(106,'Indian Red Cross Society Blood Bank','Delhi',01551),
(107,'Lions Blood Bank','Bangalore',26807),
(108,'Jeeva Voluntary Blood Bank','Bangalore',11338),
(109,'IMA Blood Bank of Uttarakhand','Dehradun',96123),
(110,'Apollo Blood Bank','Hyderabad',98701),
(111,'Care Blood Center','Chennai',98702),
(112,'Hope Blood Bank','Mumbai',98703),
(113,'LifeCare Blood Bank','Kolkata',98704),
(114,'Unity Blood Center','Pune',98705),
(115,'Sunrise Blood Bank','Lucknow',98706),
(116,'Faith Blood Bank','Chandigarh',98707),
(117,'Healing Hands Blood Bank','Ahmedabad',98708),
(118,'Sanjeevani Blood Bank','Patna',98709),
(119,'Trust Blood Center','Surat',98710),
(120,'Global Blood Bank','Indore',98711),
(121,'Heritage Blood Bank','Varanasi',98712),
(122,'Metro Blood Center','Nagpur',98713),
(123,'Sahara Blood Bank','Coimbatore',98714),
(124,'Lotus Blood Bank','Visakhapatnam',98715),
(125,'Cure Blood Center','Amritsar',98716),
(126,'Grace Blood Bank','Bhopal',98717),
(127,'CareWell Blood Bank','Ranchi',98718),
(128,'LifeLine Blood Bank','Mangalore',98719),
(129,'RedHope Blood Center','Thiruvananthapuram',98720),
(130,'Wellness Blood Bank','Guwahati',98721),
(131,'Relief Blood Bank','Raipur',98722),
(132,'Charity Blood Bank','Jodhpur',98723),
(133,'Guardian Blood Bank','Agra',98724),
(134,'Helping Hands Blood Bank','Kanpur',98725),
(135,'Seva Blood Center','Madurai',98726),
(136,'Smile Blood Bank','Nashik',98727),
(137,'Swasthya Blood Bank','Aurangabad',98728),
(138,'Harmony Blood Bank','Gwalior',98729),
(139,'Sankalp Blood Center','Mysore',98730),
(140,'Raksha Blood Bank','Vadodara',98731),
(141,'Medico Blood Bank','Meerut',98732),
(142,'Humanity Blood Bank','Tirupati',98733),
(143,'Ujjwal Blood Bank','Shimla',98734),
(144,'CarePoint Blood Bank','Udaipur',98735),
(145,'LifeTrust Blood Bank','Noida',98736),
(146,'ReliefPoint Blood Bank','Faridabad',98737),
(147,'Noble Blood Center','Ghaziabad',98738),
(148,'AidPlus Blood Bank','Puducherry',98739),
(149,'CityCare Blood Bank','Vijayawada',98740),
(150,'QuickCare Blood Bank','Jabalpur',98741),
(151,'Sparsh Blood Bank','Aligarh',98742),
(152,'ServeWell Blood Bank','Siliguri',98743),
(153,'Medilife Blood Bank','Kochi',98744),
(154,'Jeevan Blood Bank','Kota',98745),
(155,'SmileCare Blood Bank','Bareilly',98746),
(156,'GreenLife Blood Bank','Bhavnagar',98747),
(157,'SafeHands Blood Bank','Kolhapur',98748),
(158,'HopeCare Blood Bank','Cuttack',98749),
(159,'BrightBlood Bank','Durgapur',98750),
(160,'HealthAid Blood Bank','Warangal',98751),
(161,'Prime Blood Bank','Guntur',98752),
(162,'TrustLife Blood Bank','Goa',98753);

select *from BloodBanks;
--------------------------------------------------------
-- 3. Table: BloodInventory
--------------------------------------------------------
CREATE TABLE BloodInventory (
    InventoryID INT PRIMARY KEY,
    BloodBankID INT,
    BloodType VARCHAR(3),
    Quantity INT CHECK (Quantity >= 0),
    FOREIGN KEY (BloodBankID) REFERENCES BloodBanks(BloodBankID)
);


INSERT INTO BloodInventory (InventoryID, BloodBankID, BloodType, Quantity) VALUES
(1,101,'B+',10),
(2,102,'A+',5),
(3,103,'O+',4),
(4,104,'AB-',8),
(5,105,'AB+',9),
(6,107,'O-',4),
(7,108,'A-',6),
(8,109,'O+',12),
(9,110,'A-',7),
(10,111,'B+',5),
(11,112,'AB+',9),
(12,113,'O-',4),
(13,114,'A+',11),
(14,115,'B-',6),
(15,116,'AB-',3),
(16,117,'O+',8),
(17,118,'A-',5),
(18,119,'B+',10),
(19,120,'AB+',7),
(20,121,'O-',6),
(21,122,'A+',14),
(22,123,'B-',4),
(23,124,'AB-',8),
(24,125,'O+',9),
(25,126,'A-',5),
(26,127,'B+',12),
(27,128,'AB+',6),
(28,129,'O-',7),
(29,130,'A+',10),
(30,131,'B-',5),
(31,132,'AB-',4),
(32,133,'O+',11),
(33,134,'A-',9),
(34,135,'B+',6),
(35,136,'AB+',7),
(36,137,'O-',3),
(37,138,'A+',12),
(38,139,'B-',8),
(39,140,'AB-',6),
(40,141,'O+',10),
(41,142,'A-',4),
(42,143,'B+',7),
(43,144,'AB+',5),
(44,145,'O-',9),
(45,146,'A+',11),
(46,147,'B-',6),
(47,148,'AB-',4),
(48,149,'O+',8),
(49,150,'A-',7),
(50,151,'B+',5),
(51,152,'AB+',9),
(52,153,'O-',6),
(53,154,'A+',13),
(54,155,'B-',4),
(55,156,'AB-',5),
(56,157,'O+',12),
(57,158,'A-',8);
select *from BloodInventory;
--------------------------------------------------------
-- 4. Table: Recipients
--------------------------------------------------------
CREATE TABLE Recipients (
    RecipientID INT PRIMARY KEY,
    Name VARCHAR(100),
    BloodTypeNeeded VARCHAR(3)
);

INSERT INTO Recipients (RecipientID, Name, BloodTypeNeeded) VALUES
(1, 'satya', 'A+'),
(2, 'naidu', 'O-'),
(3, 'sana', 'AB+'),
(4,'Ananya','O+'),
(5,'Rahul','B+'), 
(6,'Kavya','AB-'),
(7, 'Ishita', 'A+'),
(8, 'Arjun', 'O+'),
(9, 'Meera', 'B-'),
(10, 'Vikram', 'AB+'),
(11, 'Tanya', 'A-'),
(12, 'Aditya', 'O-'),
(13, 'Rhea', 'B+'),
(14, 'Kunal', 'AB-'),
(15, 'Sneha', 'A+'),
(16, 'Rohan', 'O+'),
(17, 'Nisha', 'B+'),
(18, 'Kabir', 'AB+'),
(19, 'Diya', 'O-'),
(20, 'Krishna', 'A-'),
(21, 'Lavanya', 'B-'),
(22, 'Aryan', 'O+'),
(23, 'Mira', 'A+'),
(24, 'Yash', 'AB+'),
(25, 'Simran', 'B+'),
(26, 'Om', 'O-'),
(27, 'Anvi', 'A+'),
(28, 'Siddharth', 'B-'),
(29, 'Neha', 'O+'),
(30, 'Parth', 'AB-'),
(31, 'Muskan', 'A-'),
(32, 'Atharv', 'O+'),
(33, 'Sara', 'B+'),
(34, 'Dev', 'AB+'),
(35, 'Pooja', 'A+'),
(36, 'Kiran', 'O-'),
(37, 'Aisha', 'B-'),
(38, 'Rudra', 'AB+'),
(39, 'Tanvi', 'A+'),
(40, 'Naman', 'O+'),
(41, 'Priya', 'AB-'),
(42, 'Harsh', 'B+'),
(43, 'Avni', 'O-'),
(44, 'Reyansh', 'A+'),
(45, 'Ira', 'O+'),
(46, 'Dhruv', 'B+'),
(47, 'Anaya', 'AB+'),
(48, 'Mohit', 'A-'),
(49, 'Suhani', 'O-'),
(50, 'Arya', 'B-'),
(51, 'Manav', 'AB+'),
(52, 'Shreya', 'O+'),
(53, 'Raj', 'A+'),
(54, 'Mahi', 'AB-'),
(55, 'Kavita', 'O-'),
(56, 'Virat', 'B+');
select *from Recipients;
--------------------------------------------------------
-- 6. Table: Donations
--------------------------------------------------------
CREATE TABLE Donations (
    DonationID INT PRIMARY KEY,
    DonarID INT,
    BloodType VARCHAR(3),
    Quantity INT CHECK (Quantity > 0),
    DonationDate DATE,
    BloodBankID INT,
    FOREIGN KEY (DonarID) REFERENCES Donars(DonarID),
    FOREIGN KEY (BloodBankID) REFERENCES BloodBanks(BloodBankID)
);

INSERT INTO Donations (DonationID, DonarID, BloodType, Quantity, DonationDate, BloodBankID) VALUES
(1, 1, 'A+', 1, '2025-01-01', 101),
(2, 2, 'O-', 2, '2025-02-15', 102),
(3, 3, 'B+', 1, '2025-03-10', 101),
(4, 4, 'AB+', 1, '2025-04-05', 103),
(5, 5, 'O+', 2, '2025-05-20', 102),
(6, 6, 'B-', 1, '2025-02-18', 102),
(7, 7, 'O+', 2, '2025-03-20', 101),
(8, 8, 'AB-', 1, '2025-04-25', 103),
(9, 9, 'A+', 1, '2025-01-15', 101),
(10, 10, 'O-', 1, '2025-02-22', 102);

select *from Donations;

CREATE TABLE DonarRecipient (
    DonarID INT,
    RecipientID INT,
    DonationDate DATE,
    PRIMARY KEY (DonarID, RecipientID, DonationDate),
    FOREIGN KEY (DonarID) REFERENCES Donars(DonarID),
    FOREIGN KEY (RecipientID) REFERENCES Recipients(RecipientID)
);
INSERT INTO DonarRecipient (DonarID, RecipientID, DonationDate) VALUES
(1, 1, '2025-01-01'),
(2, 2, '2025-01-02'),
(3, 3, '2025-01-03'),
(4, 4, '2025-01-04'),
(5, 5, '2025-01-05'),
(6, 6, '2025-01-06'),
(7, 7, '2025-01-07'),
(8, 8, '2025-01-08'),
(9, 9, '2025-01-09'),
(10, 10, '2025-01-10');
select *from DonarRecipient;

CREATE TABLE BloodBankRecipient (
    BloodBankID INT,
    RecipientID INT,
    BloodTypeProvided VARCHAR(3),
    Quantity INT CHECK (Quantity > 0),
    TransactionDate DATE,
    PRIMARY KEY (BloodBankID, RecipientID, TransactionDate),
    FOREIGN KEY (BloodBankID) REFERENCES BloodBanks(BloodBankID),
    FOREIGN KEY (RecipientID) REFERENCES Recipients(RecipientID)
);

INSERT INTO BloodBankRecipient (BloodBankID, RecipientID, BloodTypeProvided, Quantity, TransactionDate) VALUES
(101, 1, 'A+', 2, '2025-01-01'),
(102, 2, 'O-', 3, '2025-01-02'),
(103, 3, 'B+', 1, '2025-01-03'),
(104, 4, 'AB-', 4, '2025-01-04'),
(105, 5, 'A-', 2, '2025-01-05');

select *from BloodBankRecipient;

CREATE TABLE DonarInventory (
    DonarID INT,
    InventoryID INT,
    Quantity INT CHECK (Quantity > 0),
    DonationDate DATE,
    PRIMARY KEY (DonarID, InventoryID),
    FOREIGN KEY (DonarID) REFERENCES Donars(DonarID),
    FOREIGN KEY (InventoryID) REFERENCES BloodInventory(InventoryID)
);

INSERT INTO DonarInventory (DonarID, InventoryID, Quantity, DonationDate) VALUES
(1, 1, 1, '2025-01-01'),
(2, 2, 2, '2025-01-02'),
(3, 3, 1, '2025-01-03'),
(4, 4, 3, '2025-01-04'),
(5, 5, 2, '2025-01-05'),
(6, 6, 1, '2025-01-06'),
(7, 7, 4, '2025-01-07'),
(8, 8, 2, '2025-01-08'),
(9, 9, 3, '2025-01-09'),
(10, 10, 1, '2025-01-10');
select *from DonarInventory;


### 1. Retrieve Donors by Blood Type
SELECT DonarID, Name, BloodType, ContactNumber
FROM  Donars
WHERE BloodType = 'O-';  


### 2. Blood Inventory Status
SELECT BloodType, SUM(Quantity) AS TotalUnits
FROM BloodInventory
WHERE BloodBankID = 101  -- Specific blood bank
GROUP BY BloodType;

### 3. Donations Made by a Donar
SELECT d.DonationID, d.DonationDate, d.Quantity, d.BloodType
FROM Donations d
WHERE d.DonarID = 1;  -- Donar with ID 1

### 4. Compatible Donars for a Recipient (A+)
SELECT DonarID, Name, BloodType
FROM Donars
WHERE BloodType IN ('A+', 'O+');  -- Compatible types for A+

### 5. Blood Banks with Low Stock (Threshold < 5 units)
SELECT bi.BloodBankID, bb.Name, bi.BloodType, bi.Quantity
FROM BloodInventory bi
JOIN BloodBanks bb ON bi.BloodBankID = bb.BloodBankID
WHERE bi.Quantity < 5;

### 6. Total Donations by Blood Type
SELECT BloodType, COUNT(*) AS DonationCount, SUM(Quantity) AS TotalUnits
FROM Donations
GROUP BY BloodType;

### 7. Donors Eligible for Next Donation
SELECT DonarID, Name, LastDonationDate
FROM Donars
WHERE LastDonationDate <= DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH);

### 8. Blood Type Distribution Among Donors
SELECT BloodType, COUNT(DonarID) AS DonorCount
FROM Donars
GROUP BY BloodType
ORDER BY DonorCount DESC;

### 10. Update Blood Inventory After Donation
UPDATE BloodInventory
SET Quantity = Quantity + 1
WHERE BloodBankID = 101 AND BloodType = 'A+';

select *from BloodInventory;

###11.Joining Multiple Tables: Donors, Donations, BloodBanks for reports.
SELECT d.Name AS Donar, b.Name AS BloodBank, don.Quantity
FROM Donars d
JOIN Donations don ON d.DonarID = don.DonarID
JOIN BloodBanks b ON don.BloodBankID = b.BloodBankID;

###12.Blood TYpe wit total quantity>5units(from blood inventory)

SELECT bi.BloodType,SUM(bi.Quantity) AS TotalQunatity 
FROM BloodInventory bi
GROUP BY bi.BloodType
Having SUM(bi.Quantity)>5;


### 13.Top 5 Active Donors by Volume
SELECT d.name, COUNT(*) AS donation_count
FROM Donations do
JOIN Donars d ON d.DonarID = d.DonarID
GROUP BY d.DonarID
ORDER BY donation_count DESC
LIMIT 5;